#include<stdio.h>
#define x 3
void main()
{
	int a=3;
	float b=5.6;
	while(a<20)
	{
		a = a + 1;
		printf(“%d”, a);
	}
	a++;	
}
