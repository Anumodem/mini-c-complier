#include<stdio.h>
void main()
{
	int a=5;
	//identifier rule broken
	float 3b = 9.5;					
}
