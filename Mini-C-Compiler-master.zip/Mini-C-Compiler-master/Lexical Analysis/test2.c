#include<stdio.h>
void main()
{
	signed int a = -2;
	//Single line comment
	printf("%d\n", a);
	/* Multiline
	comment */
}
