#include<stdio.h>
void main()
{
	int a = 8;
	float b = 9.5.7;
	//constant error
}
