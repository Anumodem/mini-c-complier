//without error - while and for loop
#include<stdio.h>
#define x 3
int main()
{
	int a=4;
	int i;
	while(a<10)
	{
		a++;
	}
	for(i=1;i<5;i++)
		a--;
}
