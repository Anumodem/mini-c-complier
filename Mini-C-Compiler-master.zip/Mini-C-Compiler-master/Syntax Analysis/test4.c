//with error - mispelled keyword 'while' and unmatched paranthesis
#include<stdio.h>
#define x 3
int main()
{
	int a=4;
	whle(a<10)
	{
		printf("%d",a);
		j=1;
		while(j<=4)
			j++;
	}	//unmatched paranthesis
	}	
}
