#include <stdio.h>
int main()
{
	int a=4;
	b=9;		//undeclared variable
	a=10;
	return 0;
}
