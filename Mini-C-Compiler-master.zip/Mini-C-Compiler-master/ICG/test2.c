#include <stdio.h>
int main()
{
	int a=5;
	int b=6;
	if(a<=7)
		b=b-4;
	else
		b=b+3;
	return 0;
}
