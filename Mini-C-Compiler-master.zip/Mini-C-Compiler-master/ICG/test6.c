#include <stdio.h>
int main()
{
	int a=5;
	int b=6;
	if(a<=7)
	{
		if(a==9)
		{
			b=b*8;
			b=9;
		}
		else
		{
			a=10;
		}
	}
	else
	{
		b=2;
	}
	return 0;
}
