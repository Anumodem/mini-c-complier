#include <stdio.h>
int main()
{
	int a=5;
	int b=6;
	int c=8;
	for(a=9;a!=6;a=a-1)
	{
		b=b+4;
		c=c-1;
	}
	b=b/9;
	return 0;
}
