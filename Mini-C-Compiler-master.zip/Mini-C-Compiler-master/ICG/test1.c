#include <stdio.h>
int main()
{
	int a=5;
	int b=6;
	int d=a+b-c*a/d;
	return 0;
}
