#include <stdio.h>
int main()
{
	int d=3;
	int a[10];
	int x=a[d-2];
	return 0;
}
