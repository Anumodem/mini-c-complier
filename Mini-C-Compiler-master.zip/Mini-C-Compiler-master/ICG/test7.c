#include <stdio.h>
int main()
{
	int a=5;
	int b=6;
	while(a>7)
	{
		b=6;
		while(b>=5)
		{
			a=9;
		}
	}
	return 0;
}
