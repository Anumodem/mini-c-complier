#include <stdio.h>
int main()
{
	int a=5;
	int b=6;
	while(a<20)
	{
		b=b+1;
		a=a+1;
	}
	return 0;
}
